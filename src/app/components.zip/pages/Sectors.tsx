import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { AnimatedSection } from "../components/AnimatedSection";
import CIS from "../../assets/CIS.jpg";
import construction from "../../assets/International_Construction.jpg";
import hospitality from "../../assets/Dara_Hotel.avif";
import environment from "../../assets/environment.jpg";
import running from "../../assets/Koh-pich-running.jpg";
import IndependenceHotel from "../../assets/independence-hotel.jpg";
import airportsunset from "../../assets/TIA_Sunset.jpg";
import { 
  Wheat, 
  Plane, 
  HardHat, 
  Package, 
  GraduationCap, 
  Heart, 
  Hotel, 
  TreePalm,
  Radio,
  Building2,
  ShoppingBag,
  Home
} from "lucide-react";

// Placeholder images - replace with actual images
const placeholderImage = "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80";

interface Sector {
  id: string;
  name: string;
  icon: React.ElementType;
  tagline: string;
  description: string;
  highlights: string[];
  image: string;
  color: string;
}

const sectors: Sector[] = [
  {
    id: "agriculture",
    name: "Agriculture",
    icon: Wheat,
    tagline: "Cultivating Tomorrow's Harvest",
    description: "OCIC's agricultural division focuses on sustainable farming practices and food security initiatives that support Cambodia's rural communities and economic growth. We invest in modern agricultural technologies and practices that enhance productivity while preserving the environment.",
    highlights: [
      "Sustainable farming initiatives",
      "Advanced irrigation systems",
      "Crop diversification programs",
      "Rural community development"
    ],
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=1200&q=80",
    color: "#22c55e"
  },
  {
    id: "airport",
    name: "Airport",
    icon: Plane,
    tagline: "Gateway to Cambodia",
    description: "Through Cambodia Airport Investment Co., Ltd. (CAIC), OCIC developed Techo International Airport, a state-of-the-art aviation facility located 20 kilometers south of Phnom Penh. Spanning 2,600 hectares, this modern airport serves as Cambodia's primary international gateway, supporting the nation's growing tourism and business sectors.",
    highlights: [
      "Modern terminal facilities",
      "International connectivity",
      "Advanced aviation technology",
      "Economic growth driver"
    ],
    image: airportsunset,
    color: "#0ea5e9"
  },
  {
    id: "construction-engineering",
    name: "Construction & Engineering",
    icon: HardHat,
    tagline: "Building Cambodia's Future",
    description: "Our construction and engineering arm delivers world-class infrastructure projects that shape Cambodia's urban landscape. From commercial towers to residential complexes, we combine innovative design with superior craftsmanship to create structures that stand the test of time.",
    highlights: [
      "Large-scale infrastructure projects",
      "Green building practices",
      "Quality assurance standards",
      "Skilled workforce development"
    ],
    image: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=1200&q=80",
    color: "#f59e0b"
  },
  {
    id: "distribution",
    name: "Distribution",
    icon: Package,
    tagline: "Connecting Markets, Delivering Value",
    description: "OCIC's distribution network ensures efficient supply chain management across Cambodia and the region. We facilitate the movement of goods from manufacturers to consumers, supporting local businesses and international trade partnerships.",
    highlights: [
      "Extensive distribution network",
      "Cold chain logistics",
      "Import-export expertise",
      "Real-time inventory management"
    ],
    image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=1200&q=80",
    color: "#8b5cf6"
  },
  {
    id: "education",
    name: "Education",
    icon: GraduationCap,
    tagline: "Empowering Through Knowledge",
    description: "We invest in educational institutions and programs that prepare Cambodia's youth for the challenges of tomorrow. Our education initiatives span from primary schools to higher education institutions, focusing on quality learning environments and modern curricula.",
    highlights: [
      "Modern learning facilities",
      "International curriculum standards",
      "Scholarship programs",
      "Teacher training initiatives"
    ],
    image: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1200&q=80",
    color: "#06b6d4"
  },
  {
    id: "healthcare",
    name: "Healthcare",
    icon: Heart,
    tagline: "Caring for Cambodia's Wellbeing",
    description: "OCIC is committed to improving healthcare accessibility and quality across Cambodia. Our healthcare investments include modern medical facilities, specialized clinics, and health education programs that serve communities nationwide.",
    highlights: [
      "State-of-the-art medical facilities",
      "Specialized treatment centers",
      "Community health programs",
      "Medical equipment & technology"
    ],
    image: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1200&q=80",
    color: "#ef4444"
  },
  {
    id: "hospitality",
    name: "Hospitality",
    icon: Hotel,
    tagline: "Defining Cambodian Hospitality",
    description: "Through partnerships like Dara Hotels Group, OCIC develops premium hospitality properties that showcase Cambodia's warmth and cultural richness. Our hotels and resorts deliver exceptional guest experiences while supporting the tourism industry.",
    highlights: [
      "Luxury hotel properties",
      "World-class amenities",
      "Cultural tourism integration",
      "Professional hospitality training"
    ],
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200&q=80",
    color: "#ec4899"
  },
  {
    id: "leisure",
    name: "Leisure",
    icon: TreePalm,
    tagline: "Creating Memorable Experiences",
    description: "OCIC develops leisure and entertainment venues that enrich the quality of life for Cambodians and visitors alike. From recreational facilities to cultural centers, we create spaces where communities gather, celebrate, and connect.",
    highlights: [
      "Recreation & sports facilities",
      "Entertainment venues",
      "Cultural preservation",
      "Community event spaces"
    ],
    image: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=1200&q=80",
    color: "#14b8a6"
  },
  {
    id: "media",
    name: "Media",
    icon: Radio,
    tagline: "Amplifying Cambodia's Voice",
    description: "Our media investments support information dissemination and cultural expression across Cambodia. We believe in the power of media to educate, entertain, and connect communities in an increasingly digital world.",
    highlights: [
      "Broadcasting infrastructure",
      "Digital media platforms",
      "Content production",
      "Journalism development"
    ],
    image: "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=1200&q=80",
    color: "#f43f5e"
  },
  {
    id: "real-estate",
    name: "Real Estate",
    icon: Building2,
    tagline: "Developing Spaces, Building Communities",
    description: "OCIC's real estate portfolio includes iconic developments like Canadia Tower and Koh Pich. We create integrated communities that combine residential, commercial, and public spaces, setting new standards for urban development in Cambodia.",
    highlights: [
      "Mixed-use developments",
      "Smart city integration",
      "Sustainable urban planning",
      "Premium office spaces"
    ],
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&q=80",
    color: "#6366f1"
  },
  {
    id: "retail",
    name: "Retail",
    icon: ShoppingBag,
    tagline: "Transforming the Shopping Experience",
    description: "OCIC develops modern retail spaces that bring international shopping experiences to Cambodia. Our retail properties provide platforms for local and international brands to connect with Cambodia's growing consumer market.",
    highlights: [
      "Modern shopping centers",
      "Retail management expertise",
      "Brand partnerships",
      "Customer experience innovation"
    ],
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&q=80",
    color: "#a855f7"
  },
  {
    id: "property-development",
    name: "Property Development",
    icon: Home,
    tagline: "Creating Homes, Building Dreams",
    description: "Our property development projects, including Norea City, provide quality housing solutions for Cambodians. Spanning over 125 hectares, our developments integrate residential, commercial, and recreational spaces to create vibrant, livable communities.",
    highlights: [
      "Master-planned communities",
      "Affordable housing initiatives",
      "Green space integration",
      "Modern infrastructure"
    ],
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200&q=80",
    color: "#10b981"
  }
];

export default function Sectors() {
  const [activeSection, setActiveSection] = useState<string>("");

  useEffect(() => {
    const handleScroll = () => {
      const sectorElements = sectors.map(s => document.getElementById(s.id));
      
      for (const element of sectorElements) {
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 150 && rect.bottom >= 150) {
            setActiveSection(element.id);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll(); // Initial check
    
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    // Handle hash navigation on page load
    const hash = window.location.hash.substring(1);
    if (hash) {
      setTimeout(() => {
        const element = document.getElementById(hash);
        if (element) {
          const offset = 100;
          const elementPosition = element.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - offset;
          window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
          });
        }
      }, 100);
    }
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <div className="min-h-screen bg-white font-montserrat">
      {/* Hero Section */}
      <section className="relative h-[60vh] flex items-center justify-center" style={{ backgroundColor: '#212721' }}>
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#212721]"></div>
          <img 
            src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1600&q=80" 
            alt="OCIC Sectors"
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl lg:text-6xl mb-6 text-white"
            style={{ fontWeight: 600 }}
          >
            Our Sectors
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-white/90 max-w-3xl mx-auto"
            style={{ fontWeight: 400 }}
          >
            Diversified investments across industries that drive Cambodia's economic growth and development
          </motion.p>
        </div>
      </section>

      {/* Quick Navigation */}
      <section className="sticky top-16 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="overflow-x-auto scrollbar-hide">
            <div className="flex gap-2 py-4 min-w-max">
              {sectors.map((sector) => (
                <button
                  key={sector.id}
                  onClick={() => scrollToSection(sector.id)}
                  className={`
                    px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap
                    ${activeSection === sector.id 
                      ? 'bg-[#B14240] text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}
                  `}
                >
                  {sector.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Sectors Content */}
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-16">
        {sectors.map((sector, index) => (
          <AnimatedSection key={sector.id}>
            <section 
              id={sector.id}
              className="mb-32 scroll-mt-32"
            >
              <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
                {/* Content */}
                <div className={`${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                  <motion.div
                    initial={{ opacity: 0, x: index % 2 === 0 ? -40 : 40 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.3 }}
                    transition={{ duration: 0.6 }}
                  >
                    {/* Icon */}
                    <div 
                      className="inline-flex p-4 rounded-2xl mb-6"
                      style={{ backgroundColor: `${sector.color}15` }}
                    >
                      <sector.icon 
                        size={40} 
                        style={{ color: sector.color }}
                        strokeWidth={1.5}
                      />
                    </div>

                    {/* Title & Tagline */}
                    <h2 
                      className="text-4xl mb-3"
                      style={{ fontWeight: 600, color: '#212721' }}
                    >
                      {sector.name}
                    </h2>
                    <p 
                      className="text-xl mb-6 italic"
                      style={{ color: sector.color, fontWeight: 500 }}
                    >
                      {sector.tagline}
                    </p>

                    {/* Description */}
                    <p 
                      className="text-base mb-8 leading-relaxed"
                      style={{ color: '#4F5B5B' }}
                    >
                      {sector.description}
                    </p>

                    {/* Highlights */}
                    <div className="mb-8">
                      <h3 
                        className="text-lg mb-4"
                        style={{ fontWeight: 600, color: '#212721' }}
                      >
                        Key Highlights
                      </h3>
                      <ul className="space-y-3">
                        {sector.highlights.map((highlight, i) => (
                          <li key={i} className="flex items-start gap-3">
                            <div 
                              className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0"
                              style={{ backgroundColor: sector.color }}
                            ></div>
                            <span 
                              className="text-sm"
                              style={{ color: '#4F5B5B' }}
                            >
                              {highlight}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* CTA Button */}
                    <motion.a
                      href="/contact"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.97 }}
                      className="inline-block px-8 py-3 rounded-full text-white text-sm transition-all"
                      style={{ backgroundColor: '#B14240', fontWeight: 600 }}
                    >
                      Learn More
                    </motion.a>
                  </motion.div>
                </div>

                {/* Image */}
                <div className={`${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                  <motion.div
                    initial={{ opacity: 0, x: index % 2 === 0 ? 40 : -40 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.3 }}
                    transition={{ duration: 0.6 }}
                    className="relative"
                  >
                    <div 
                      className="absolute -inset-4 rounded-3xl opacity-20"
                      style={{ backgroundColor: sector.color }}
                    ></div>
                    <img 
                      src={sector.image}
                      alt={sector.name}
                      className="relative rounded-2xl w-full h-[400px] lg:h-[500px] object-cover shadow-xl"
                    />
                  </motion.div>
                </div>
              </div>
            </section>
          </AnimatedSection>
        ))}
      </div>

      {/* Call to Action Section */}
      <AnimatedSection>
        <section className="py-20 lg:py-32" style={{ backgroundColor: '#212721' }}>
          <div className="max-w-[1440px] mx-auto px-6 lg:px-12 text-center">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-4xl lg:text-5xl mb-6 text-white"
              style={{ fontWeight: 600 }}
            >
              Partner With Us
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-lg text-white/80 mb-10 max-w-2xl mx-auto"
            >
              Explore investment opportunities and partnerships across our diverse portfolio of sectors
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <a
                href="/contact"
                className="inline-block px-10 py-4 rounded-full text-white text-base transition-all hover:opacity-90 hover:scale-105"
                style={{ backgroundColor: '#B14240', fontWeight: 600 }}
              >
                Get in Touch
              </a>
              <a
                href="/about"
                className="inline-block px-10 py-4 rounded-full text-white text-base transition-all hover:bg-white/10 border-2 border-white"
                style={{ fontWeight: 600 }}
              >
                Learn About OCIC
              </a>
            </motion.div>
          </div>
        </section>
      </AnimatedSection>
    </div>
  );
}