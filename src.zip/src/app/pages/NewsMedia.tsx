export default function NewsMedia() {
  return (
    <section className="mx-auto max-w-[1280px] px-6 py-24 lg:px-20">
      <h1 className="text-4xl font-semibold">News & Media</h1>
      <p className="mt-4 text-black/70">This page is a placeholder. We can build it next using the same OCIC components and styling.</p>
    </section>
  );
}
